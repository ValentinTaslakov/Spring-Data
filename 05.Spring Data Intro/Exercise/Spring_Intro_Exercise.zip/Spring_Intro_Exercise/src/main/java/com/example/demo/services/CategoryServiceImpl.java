package com.example.demo.services;

import com.example.demo.entities.Category;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class CategoryServiceImpl implements CategoryService {
    @Override
    public Set<Category> getRandomCategories() {
        return null;
    }
}
