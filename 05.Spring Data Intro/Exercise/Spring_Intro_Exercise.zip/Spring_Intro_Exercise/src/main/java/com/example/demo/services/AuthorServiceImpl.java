package com.example.demo.services;

import com.example.demo.entities.Author;
import org.springframework.stereotype.Service;

@Service
public class AuthorServiceImpl implements AuthorService {
    @Override
    public Author getRandomAuthor() {
        return null;
    }
}
