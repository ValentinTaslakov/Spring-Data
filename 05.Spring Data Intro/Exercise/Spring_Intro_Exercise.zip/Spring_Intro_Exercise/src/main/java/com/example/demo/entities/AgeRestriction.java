package com.example.demo.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
